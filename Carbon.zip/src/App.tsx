import { AllRoutes } from './routes/Routes'
import './App.css'


function App() {

  return (
    <>
      <AllRoutes/>
    </>
  )
}

export default App
