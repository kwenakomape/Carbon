import express from "express";
import mysql from "mysql2";
import bodyParser from "body-parser";
import cors from "cors";
import { Infobip, AuthType } from "@infobip-api/sdk";
import crypto from "crypto";
import dayjs from "dayjs";
import {sendEmail} from './utils/emailSender.js';
import {generateAppointmentConfirmationHTML} from "./emailTemplates/appointmentConfirmation.js";
import {generateInvoiceEmailHTML} from "./emailTemplates/invoiceEmail.js";



const app = express();
app.use(bodyParser.json());
app.use(cors());

const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "12345",
  database: "carbondb",
});

db.connect((err) => {
  if (err) {
    console.error("Error connecting to the database:", err);
    return;
  }
  console.log("Connected to the database");
});

const infobipClient = new Infobip({
  baseUrl: "xk94el.api.infobip.com",
  apiKey:
    "abc09110b918bb66712f677c79f107c4-a44701bc-b6f9-40f8-8dc2-db651143b080",
  authType: AuthType.ApiKey,
});

const otpStore = new Map(); // Store OTPs temporarily

// Generate a random OTP
function generateOtp() {
  return crypto.randomInt(1000, 9999).toString();
}

async function sendAppointmentMessage(phoneNumber, message) {

  return await sendSms(phoneNumber, message);
}
async function sendOtp(phoneNumber) {
  const otp = generateOtp();
  otpStore.set(phoneNumber, otp);
  const message = `Your OTP code is ${otp}`;
  return await sendSms(phoneNumber, message);
}
async function sendSms(phoneNumber, message) {
  try {
    const response = await infobipClient.channels.sms.send({
      type: "text",
      messages: [
        {
          destinations: [{ to: phoneNumber }],
          from: "YourSenderID",
          text: message,
        },
      ],
    });
    console.log("SMS sent:", response.data);
    return true;
  } catch (error) {
    console.error("Error sending SMS:", error);
    return false;
  }
}

// Verify OTP
function verifyOtp(phoneNumber, otp) {
  const storedOtp = otpStore.get(phoneNumber);
  if (storedOtp === otp) {
    otpStore.delete(phoneNumber); // Remove OTP after verification
    return true;
  }
  return false;
}

app.post("/check-username", (req, res) => {
  const { username } = req.body;

  const checkEmailQuery = "SELECT * FROM Admin WHERE email = ?";
  const checkIDQuery = "SELECT * FROM Members WHERE member_id = ?";

  if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(username)) {
    db.query(checkEmailQuery, [username], (err, results) => {
      if (err) {
        return res.status(500).send("Database error");
      }
      res.send({
        exists: results.length > 0,
        type: "email",
        erroMessage: "Username does not exist",
      });
    });
  } else if (/^\d+$/.test(username)) {
    db.query(checkIDQuery, [username], (err, results) => {
      if (err) {
        return res.status(500).send("Database error");
      }
      if (results.length > 0) {
        const { cell } = results[0];
        res.send({
          exists: true,
          type: "id",
          Cell: cell,
          erroMessage: "Username does not exist",
        });
      } else {
        res.send({
          exists: false,
          type: "id",
          erroMessage: "Username does not exist",
        });
      }
    });
  } else if (username === "") {
    res.send({
      exists: false,
      type: "invalid",
      erroMessage: "Field Empty,Please Enter Username",
    });
  } else {
    res.send({
      exists: false,
      type: "invalid",
      erroMessage: "Username does not exist",
    });
  }
});


app.post("/send-otp", async (req, res) => {
  const { Cell } = req.body;
  const phoneNumber = Cell; // Assuming username is the phone number
  const success = await sendOtp(phoneNumber);
  if (success) {
    res.status(200).send("OTP sent successfully");
  } else {
    res.status(500).send("Failed to send OTP");
  }
});

app.post("/verify-otp", (req, res) => {
  const { Cell, otp } = req.body;
  const phoneNumber = Cell; // Assuming username is the phone number
  const isValid = verifyOtp(phoneNumber, otp);
  if (isValid) {
    res.status(200).send({ valid: true });
  } else {
    res.status(400).send({ valid: false });
  }
});

app.listen(3001, () => {
  console.log("Database server running on port 3001..");
});

app.post("/verify-password", (req, res) => {
  const { username, password } = req.body;
  const query = "SELECT * FROM Admin WHERE email = ?";
  db.query(query, [username], (err, results) => {
    if (err) {
      return res.status(500).send("Database error");
    }
    if (results.length > 0) {
      const storedPassword = results[0].password;
      let AdminID = results[0].admin_id;
      if (storedPassword === password) {
        res.send({ valid: true, AdminID: AdminID });
      } else {
        if (password === "") {
          res.send({
            valid: false,
            errorMessage: "Field Empty,Please Enter Password",
          });
        } else {
          res.send({ valid: false, errorMessage: "Invalid Password" });
        }
      }
    }
  });
});
app.get("/member/:id", (req, res) => {
  const memberId = req.params.id;
  const query = `
  SELECT 
    Members.member_id,
    Members.email,
    Members.name AS member_name,
    Members.cell,
    Members.joined_date,
    Members.credits,
    Appointments.appointment_id,
    Appointments.request_date,
    Appointments.confirmed_date,
    Appointments.status,
    Admin.name AS specialist_name,
    Admin.specialist_type, -- Corrected to specialist_type
    Payments.payment_method
FROM 
    Members
LEFT JOIN 
    Appointments ON Members.member_id = Appointments.member_id
LEFT JOIN 
    Admin ON Appointments.specialist_id = Admin.admin_id
LEFT JOIN 
    Payments ON Appointments.appointment_id = Payments.appointment_id
WHERE 
    Members.member_id = ?
ORDER BY 
    Members.member_id, Appointments.appointment_id`;

  db.query(query, [memberId], (err, results) => {
    if (err) {
      return res.status(500).send("Database error");
    }
    res.send(results);
  });
});
app.get("/api/appointments-with-specialist/:id", (req, res) => {
  const adminId = req.params.id;
  const query = `
          SELECT 
        a.appointment_id,
        a.member_id,
        m.name AS member_name,
        m.cell,
        a.request_date,
        a.confirmed_date,
        a.status,
        a.preferred_date1,
        a.preferred_time_range1,
        a.preferred_date2,
        a.preferred_time_range2,
        a.preferred_date3,
        a.preferred_time_range3,
        ad.name AS specialist_name,
        p.payment_method
    FROM 
        Appointments a
    JOIN 
        Members m ON a.member_id = m.member_id
    JOIN 
        Admin ad ON a.specialist_id = ad.admin_id
    LEFT JOIN 
        Payments p ON a.appointment_id = p.appointment_id
    WHERE 
        a.specialist_id = ?`;

  db.query(query, [adminId], (err, results) => {
    if (err) {
      return res.status(500).send("Database error");
    }
    res.send(results);
  });
});
app.get("/api/appointments/:id", (req, res) => {
  const appointmentId = req.params.id;
  
  const query = `
    SELECT 
        i.Invoice_Number,
        i.Date,
        m.Name AS Member_Name,
        m.Id_No AS Member_ID,
        m.Email,
        i.Payment_Method,
        s.Description,
        s.Date AS Session_Date,
        s.Duration,
        a.Name AS Specialist_Name,
        a.Specialization,
        s.Credits_Used,
        s.Amount,
        i.Total_Credits_Used,
        i.Total_Amount
    FROM 
        Invoices i
    JOIN 
        Members m ON i.Member_Id = m.Id_No
    JOIN 
        Sessions s ON i.Invoice_Id = s.Appointment_Id
    JOIN 
        Admin a ON s.Specialist_Id = a.Admin_Id
    WHERE 
        s.Appointment_Id = ?;
  `;

  db.query(query, [appointmentId], (err, results) => {
    if (err) {
      console.error("Error executing query:", err);
      res.status(500).send("Server error");
      return;
    }
    res.send(results);
  });
});

app.get("/api/paywith-credits/:id", (req, res) => {
  const memberId = req.params.id;
  const updateQuery = `UPDATE Members SET credits = credits - 80 WHERE member_id = ?`;
  const selectQuery = `SELECT Points FROM Members WHERE Id_No = ?`;

  db.query(updateQuery, [memberId], (err, updateResults) => {
    if (err) {
      return res.status(500).send("Error updating points");
    }

    db.query(selectQuery, [memberId], (err, results) => {
      if (err) {
        return res.status(500).send("Error retrieving updated points");
      }
      
      
      res.send(results);
    });
  });
});

app.post("/api/send-appointment-details", async (req, res) => {

  const { phoneNumber,selectedDate,timeRange,memberName } = req.body;
  const confirmedDate = dayjs(selectedDate).format('MMMM D, YYYY');
  const message =`Dear ${memberName}, your appointment with the BIOKINETICIST is confirmed:
Date: ${confirmedDate}
Time: ${dayjs(timeRange.start).format("HH:mm")} - ${dayjs(timeRange.end).format("HH:mm")}
Please arrive early for paperwork. Thanks!
`

  const success = await sendAppointmentMessage(phoneNumber,message);
  if (success) {
    res.status(200).send("appointment message sent successfully");
  } else {
    res.status(500).send("Failed to send appointment message");
  }
});
app.post("/api/confirm-date", (req, res) => {

  const { memberId,selectedDate,AppointmentId} = req.body;
  
  const confirmedDate = dayjs(selectedDate).format("YYYY-MM-DD");
  const query = `UPDATE Appointments SET Confirmed_Date = ?, status = 'Confirmed' WHERE member_id = ? AND appointment_id = ?`
  
  
  db.query(query, [confirmedDate, memberId,AppointmentId], (err, results) => {
    if (err) {
      return res.status(500).send("Error updating points");
    }
    res.send(`Date Updated by the Specialist`);
  });
});
app.post("/api/update-appointment-status", (req, res) => {

  const { newStatus,memberId,AppointmentId} = req.body;

  const query = `UPDATE Appointments SET status = ? WHERE member_id = ? AND appointment_id = ?`;
  
  db.query(query, [newStatus, memberId, AppointmentId], (err, results) => {
    if (err) {
      return res.status(500).send("Error updating Status");
    }
    res.send(`Status Updated Successfully`);
  });
});

// just prepopulate this data on the backend , we need interface for member so select which services they are interested
// or specialist choose which servives they offered them ,point is we need an interface to add sessions(services)
app.post('/api/sessions', (req, res) => {

  const sessions = req.body.sessions; // Expecting an array of session objects
  const sql = 'INSERT INTO Sessions (appointment_id, specialist_id, service_id, date, duration, credits_used, amount) VALUES ?';
  const values = sessions.map(session => [
    session.appointment_id,
    session.specialist_id,
    session.service_id,
    session.date,
    session.duration,
    session.credits_used,
    session.amount
  ]);

  db.query(sql, [values], (err, result) => {
    if (err) {
      res.status(500).send("Error making sessions");
      return;
    }
    res.status(200).send("Sessions created successfully");
  });
});
app.post("/api/bookings", (req, res) => {
  const { memberId, specialistId, status, selectedDates, timeRanges } =
    req.body;
  const preferred_date1 = dayjs(selectedDates[0]).format("YYYY-MM-DD");
  const preferred_time_range1 = `${dayjs(timeRanges[0].start).format('HH:mm')} to ${dayjs(timeRanges[0].end).format('HH:mm')}`;
  const preferred_date2 = dayjs(selectedDates[1]).format("YYYY-MM-DD");
  const preferred_time_range2 = `${dayjs(timeRanges[1].start).format('HH:mm')} to ${dayjs(timeRanges[1].end).format('HH:mm')}`;
  const preferred_date3 = dayjs(selectedDates[2]).format("YYYY-MM-DD");
  const preferred_time_range3 = `${dayjs(timeRanges[2].start).format('HH:mm')} to ${dayjs(timeRanges[2].end).format('HH:mm')}`;
  const query =
    "INSERT INTO Appointments (member_id, specialist_id, status,preferred_date1,preferred_time_range1,preferred_date2,preferred_time_range2,preferred_date3,preferred_time_range3) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
  db.query(
    query,
    [
      memberId,
      specialistId,
      status,
      preferred_date1,
      preferred_time_range1,
      preferred_date2,
      preferred_time_range2,
      preferred_date3,
      preferred_time_range3,
    ],
    (err, results) => {
      if (err) {
        res.status(500).send("Error booking appointment");
        return;
      }
      res.status(200).send("Appointment booked successfully");
    }
  );
});
app.post("/api/send-email", (req, res) => {
  const {
    type,
    memberName,
    selectedSpecialist,
    selectedDates,
    timeRanges,
    invoiceDetails,
    remainingCredits,
    paymentMethod,
    pdfEmailAttach,
  } = req.body;
  let mailOptions;
  switch (type) {
    case "appointmentConfirmation":
      mailOptions = {
        from: "kwenakomape3@gmail.com",
        to: "kwenakomape2@gmail.com,kwenakomape3@gmail.com",
        subject: `New Appointment Scheduled: ${memberName}`,
        html: generateAppointmentConfirmationHTML(
          memberName,
          selectedSpecialist,
          selectedDates,
          timeRanges
        ),
      };
      break;
    case "invoiceEmail":
      mailOptions = {
        from: "kwenakomape3@gmail.com",
        to: 'kwenakomape2@gmail.com,kwenakomape3@gmail.com',
        subject: invoiceDetails[0].Invoice_Number,
        html: generateInvoiceEmailHTML(
          invoiceDetails,
          paymentMethod,
          remainingCredits,
        ),
        attachments: [
          {
            filename: `${invoiceDetails[0].Invoice_Number}.pdf`,
            content: pdfEmailAttach.split("base64,")[1],
            encoding: "base64",
          },
        ],
      };
      break;
    default:
      res.status(400).send("Invalid email type");
      return;
  }
  sendEmail(mailOptions, res);
});