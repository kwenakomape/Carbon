import {
  PDFDownloadLink,
  Document,
  Page,
  Text,
  View,
  StyleSheet,
} from "@react-pdf/renderer";
import {
  Button,
  ModalHeader,
  ModalContent,
  ModalActions,
} from "semantic-ui-react";
import jsPDF from "jspdf";
import "jspdf-autotable";
import axios from "axios";
import React, { useState, useEffect } from "react";
import dayjs from "dayjs";

const styles = StyleSheet.create({
  page: { padding: 30 },
  header: { textAlign: "center", marginBottom: 20 },
  table: { width: "100%", marginBottom: 20 },
  tableRow: { flexDirection: "row", borderBottom: "1px solid #ddd" },
  tableColHeader: { flex: 1, fontWeight: "bold", padding: 5 },
  tableCol: { flex: 1, padding: 5 },
});

export const Invoice = ({
  handleNext,
  setPdfUrl,
  setPdfName,
  AppointmentId,
  paymentMethod,
  setinvoiceDetails,
  setRemainingCredits,
  memberId,
  setPdfEmailAttach,
  UpdateAppointmentStatus,
}) => {
  const [invoiceData, setInvoiceData] = useState(null);

  useEffect(() => {
    const fetchInvoiceData = async () => {
      try {
        const response = await axios.get(
          `http://localhost:3001/api/appointments/${AppointmentId}`
        );
        setInvoiceData(response.data);
        setinvoiceDetails(response.data)
      } catch (error) {
        console.error("Error Generating Invoice:", error);
      }
    };
    fetchInvoiceData();
  }, [AppointmentId]);

  const deductMemberCredits = async () => {
    try {
      const response = await axios.get(
        `http://localhost:3001/api/paywith-credits/${memberId}`
      );
      return response.data;
    } catch (error) {
      console.error("Error Deducting credits from Member Account:", error);
    }
  };
  function getRandomService(caseType) {
    let min, max;
    switch(caseType) {
        case "Biokineticist":
            min = 1;
            max = 5;
            break;
        case "Dietitian":
            min = 6;
            max = 10;
            break;
        case "Physiotherapist":
            min = 11;
            max = 15;
            break;
        default:
            throw new Error("Invalid case type. Please use 'Biokineticist', 'Dietitian', or 'Physiotherapist'.");
    }
    return Math.floor(Math.random() * (max - min + 1)) + min;
}
  const generateInvoicePDF = async () => {
    let creditsRemaining = null;
    if (paymentMethod === "SSISA CREDITS") {
      creditsRemaining = await deductMemberCredits();
      setRemainingCredits(creditsRemaining[0].Points)
      if (!creditsRemaining) {
        console.error("Failed to deduct credits");
        return;
      }
    }
    const doc = new jsPDF();
    const today = dayjs().format("D MMMM YYYY");
    doc.setFontSize(20);
    doc.text("SSISA", 105, 10, { align: "center" });
    doc.setFontSize(12);
    doc.text("Sports Science Institute of South Africa", 105, 20, {
      align: "center",
    });
    doc.text("123 Wellness Way, Cape Town, WC, South Africa", 105, 25, {
      align: "center",
    });
    doc.text("+27 21 123 4567", 105, 30, { align: "center" });
    doc.text("info@ssisa.com", 105, 35, { align: "center" });
    doc.text(`Invoice No: ${invoiceData[0].Invoice_Number}`, 10, 50);
    doc.text(`Date: ${today}`, 10, 55);
    doc.text(`Bill To:`, 10, 65);
    doc.text(`Member Name: ${invoiceData[0].Member_Name}`, 20, 70);
    doc.text(`Member ID: ${invoiceData[0].Member_ID}`, 20, 75);
    doc.text(`Email: ${invoiceData[0].Email}`, 20, 80);
    const tableHeaders =
      paymentMethod === "CASH/CARD"
        ? [
            [
              "Description",
              "Date",
              "Duration",
              "Name",
              "Specialization",
              "Amount (ZAR)",
            ],
          ]
        : [
            [
              "Description",
              "Date",
              "Duration",
              "Name",
              "Specialization",
              "Credits Used",
            ],
          ];
    const tableBody = invoiceData.map((session) => [
      session.Description,
      dayjs(session.Session_Date).format("DD MMM YYYY"),
      session.Duration,
      session.Specialist_Name,
      session.Specialization,
      paymentMethod === "CASH/CARD" ? session.Amount : session.Credits_Used,
    ]);
    doc.autoTable({ startY: 90, head: tableHeaders, body: tableBody });
    if (paymentMethod === "CASH/CARD") {
      doc.text(`Payment Method: CASH/CARD`, 10, doc.lastAutoTable.finalY + 10);
      doc.text(`Total Amount: ZAR 700.00`, 10, doc.lastAutoTable.finalY + 15);
    } else {
      doc.text(
        `Payment Method: SSISA Credits`,
        10,
        doc.lastAutoTable.finalY + 10
      );
      doc.text(`Total Credits Used: 80`, 10, doc.lastAutoTable.finalY + 15);
      doc.text(`Remaining Credits: ${creditsRemaining[0].Points}`, 10, doc.lastAutoTable.finalY + 20);
    }
    doc.text(
      "Thank you for choosing SSISA. Stay fit, stay healthy!",
      10,
      doc.lastAutoTable.finalY + 30
    );
    doc.text(
      "For any queries, please contact us at +27 21 123 4567 or info@ssisa.com.",
      10,
      doc.lastAutoTable.finalY + 35
    );

    const pdfBlob = doc.output("blob");
    const pdfUrl = URL.createObjectURL(pdfBlob);
    setPdfUrl(pdfUrl);
    setPdfName(`Invoice_${invoiceData[0].Invoice_Number}.pdf`);
    const reader = new FileReader();
    reader.readAsDataURL(pdfBlob);
    reader.onloadend = function () {
      const base64data = reader.result;
      setPdfEmailAttach(base64data)
    };
    await UpdateAppointmentStatus("Seen");
    handleNext();
  };

  return (
    <>
      <Button primary onClick={generateInvoicePDF}>
        Generate Invoice
      </Button>
    </>
  );
};
