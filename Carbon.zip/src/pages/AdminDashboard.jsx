import {
  Card,
  Icon,
  Button,
  Form,
  Popup,
  Divider,
  Dropdown,
  Input,
  HeaderContent,
  TableRow,
  TableHeaderCell,
  TableHeader,
  TableCell,
  TableBody,
  Checkbox,
  Header,
  Table,
  Segment,
  FormField,
} from "semantic-ui-react";
import useLoading from "../js/useLoading.js";
import { LoaderExampleText } from "../components/loader.jsx";

import axios from "axios";
import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { AdminModals } from "../components/AdminModals.jsx";
import dayjs from "dayjs";

export const AdminDashboard = () => {
  let { id } = useParams();
  const [data, setData] = useState(null);
  const [loading, setLoading, resetLoading] = useLoading();
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(
          `http://localhost:3001/api/appointments-with-specialist/${id}`
        );
        setData(response.data);
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [id, setLoading]);
  

  return (
    <>
      {loading ? (
        <LoaderExampleText loadingMessage="Dashboard Loading..." />
      ) : (
        <div className="userDashbaord">
          <Segment className="left-sidebar">
            <div className="left-siber-options">
              <span>
                <a className="item">
                  <Icon name="th large" />
                </a>
                <span>Dashboard</span>
              </span>
            </div>
          </Segment>
          <div className="admindashbaord-center-panel">
            <Segment id="headingMessageAdmin">
              Welcome <strong>{data[0].specialist_name} </strong>
            </Segment>
            <Table celled>
              <TableHeader>
                <TableRow>
                  <TableHeaderCell>Request Date</TableHeaderCell>
                  <TableHeaderCell>Client</TableHeaderCell>
                  <TableHeaderCell>Payment Method</TableHeaderCell>
                  <TableHeaderCell>Confirmed Date</TableHeaderCell>
                  <TableHeaderCell>Status</TableHeaderCell>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.map((appointment, index) => (
                  <TableRow key={index}>
                    <TableCell>
                      {dayjs(appointment.request_date).format('D MMMM, YYYY')}
                    </TableCell>
                    <TableCell>{appointment.member_name}</TableCell>
                    <TableCell>{appointment.payment_method
                        ? appointment.payment_method
                        : "______________"}</TableCell>
                    <TableCell>
                    {appointment.confirmed_date
                        ? dayjs(appointment.confirmed_date).format('D MMMM, YYYY')
                        : "______________"}
                    </TableCell>
                    <TableCell collapsing>
                      <div className="status-container">
                        <span>{appointment.status}</span>
                        <span>
                          <AdminModals
                            memberId={data[index].member_id}
                            memberName={data[index].member_name}
                            AppointmentId={data[index].appointment_id}
                            phoneNumber={data[index].cell}
                            preferred_date1={dayjs(data[index].preferred_date1).format('D MMMM, YYYY')}
                            preferred_time_range1={data[index].preferred_time_range1}
                            preferred_date2={dayjs(data[index].preferred_date2).format('D MMMM, YYYY')}
                            preferred_time_range2={data[index].preferred_time_range2}
                            preferred_date3={dayjs(data[index].preferred_date3).format('D MMMM, YYYY')}
                            preferred_time_range3={data[index].preferred_time_range3}
                          />
                        </span>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>
      )}
    </>
  );
};
