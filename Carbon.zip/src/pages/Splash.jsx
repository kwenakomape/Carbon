

export const Splash = () => (
   <div className="splashingPage">
      <img src="splashphoto.jpg" alt="Carbon" className="rotating-image" />
   </div>

   
  );